﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace urna
{
    class Candidato
    {
        public string codigo { get; set; }
        public string nome { get; set; }
        public string foto { get; set; }
        public string setor { get; set; }
    }
}
