﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace urna
{
    class DAL
    {
        OleDbConnection conn;
        SqlConnection conexao = null;
        private void Conexaoopen()
        {
            // it's your DB file path:
            // ApplicationEXEPath\Test.mdb
            var DBPath = Application.StartupPath + "\\Eleicao.mdb";

            conn = new OleDbConnection("Provider=Microsoft.Jet.OleDb.4.0;"
                + "Data Source=" + DBPath);
            conn.Open();
        }

        public void Selectall()
        {
            Conexaoopen();
            DataTable dt = new DataTable();
            string comandoSQL = "select * from Eleitor";
            OleDbDataAdapter adapter = new OleDbDataAdapter(comandoSQL, conn);

            try
            {
                adapter.Fill(dt);
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            conn.Dispose();
        }

        public Eleitor SelectEleitor(string matricula)
        {
            Conexaoopen();
            Eleitor eleitor = new Eleitor();
            DataTable dt = new DataTable();
            string comandoSQL = "select * from Eleitor WHERE CHAPA="+matricula;
            OleDbDataAdapter adapter = new OleDbDataAdapter(comandoSQL, conn);

            try
            {
                adapter.Fill(dt);
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            conn.Dispose();

            foreach (DataRow linha in dt.Rows)
            {
                eleitor.matricula = linha["Chapa"].ToString();
                eleitor.Nome = linha["Nome"].ToString();
                eleitor.voto = Convert.ToBoolean(linha["voto"]);
            }

            return eleitor;

        }

        public Candidato SelectCandidato(string cod)
        {
            Conexaoopen();
            Candidato candidato = new Candidato();
            DataTable dt = new DataTable();
            string comandoSQL = "SELECT * FROM Candidato WHERE Cod_Candidato=" + cod.Trim();
            OleDbDataAdapter adapter = new OleDbDataAdapter(comandoSQL, conn);

            try
            {
                adapter.Fill(dt);
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }

            conn.Dispose();

            foreach (DataRow linha in dt.Rows)
            {
                candidato.codigo = linha["Cod_Candidato"].ToString();
                candidato.nome = linha["Nome"].ToString();
                candidato.foto = linha["foto"].ToString();
                candidato.setor = linha["Setor"].ToString();
            }

            return candidato;

        }

        public void UpdateEleitorVoto(string matricula)
        {
            Conexaoopen();
            try
            {
                using (OleDbCommand cmd = new OleDbCommand("UPDATE Eleitor SET [voto]=true WHERE Chapa="+ matricula +";", conn))
                {
                    cmd.ExecuteNonQuery();
                }
                conn.Dispose();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

        public void InsertVoto(string voto)
        {
            Conexaoopen();
            try
            {
                using (OleDbCommand cmd = new OleDbCommand("INSERT INTO VOTO (cod_candidato) VALUES ("+voto+");", conn))
            {
                cmd.ExecuteNonQuery();
            }
            conn.Dispose();
            }
            catch (Exception exc)
            {
                throw new Exception(exc.Message);
            }
        }

    }
}
