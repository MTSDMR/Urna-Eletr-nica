﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace urna
{
    public partial class Form3 : Form
    {
        string num = ""; //armazena a Matricula
        Eleitor eleitor = null;
        public Form3()
        {
            InitializeComponent();
        }

        private void btnNumero(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            if (num.Length < 4)
            {
                txtMatricula.Text = txtMatricula.Text + bt.Text;
            }
        }

        private void txtMatricula_TextChanged(object sender, EventArgs e)
        {
            num = txtMatricula.Text.Trim() ;

            if(num.Length == 4)
            {
                DAL dal = new DAL();
                eleitor = dal.SelectEleitor(num.Trim());
                if (eleitor.matricula != null)
                {
                    if (eleitor.voto != true)
                    {
                        lb_Nome.Text = eleitor.Nome.Trim();
                    }
                    else
                    {
                        MessageBox.Show("Atenção: Eleitor já votou", "Atenção !", MessageBoxButtons.OK);
                        Limpar();
                    }
                }
                else
                {
                    MessageBox.Show("Matricula não cadastrada.","Atenção !",MessageBoxButtons.OK);
                    Limpar();

                }
                 
            }
            else
            {

            }

            if (num == "10")
            {
               // pictureBox1.Image = Properties.Resources.cad_Campos;
                //lblNomeCandidato.Text = "Eduardo Campos";

            }

            
            {
               // pictureBox1.Image = Properties.Resources.fundoLARANJA_urna1;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Limpar();
        }

        private void Limpar()
        {
            num = "";
            txtMatricula.Text = "";
            lb_Nome.Text = "";
            eleitor = null;
        }

        private void bt_Confirma_Click(object sender, EventArgs e)
        {
            if (eleitor != null)
            {
                Hashtable info = new Hashtable();
                info.Add("Valor1", eleitor.matricula);
                info.Add("Valor2", eleitor.Nome);

                Form1 form1 = new Form1(info);

                form1.ShowDialog();

                Limpar();
            }
        }
    }
}
