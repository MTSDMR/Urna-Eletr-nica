﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace urna
{
    class Eleitor
    {
        public string matricula { get; set; }
        public string Nome { get; set; }
        public bool voto { get; set; }
    }
}
