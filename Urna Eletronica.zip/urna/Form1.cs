﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace urna
{
    public partial class Form1 : Form
    {

        string num = "0"; //armazena o número do candidato
        bool voto = false;
        string matricula;

        int a = 0;
        Candidato candidato = new Candidato();
        public Form1(Hashtable info)
        {
            InitializeComponent();

            lb_Matricula.Text = info["Valor1"].ToString();
            lb_Nome.Text = info["Valor2"].ToString();

            matricula = info["Valor1"].ToString().Trim();
        }



        private void btnNumero(object sender, EventArgs e)
        {
            Button bt = (Button)sender;
            txtDireita.Text = txtDireita.Text + bt.Text;

        }
        private void txtDireita_TextChanged(object sender, EventArgs e)
        {
            num = txtDireita.Text;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            limpar();

        }

        private void limpar()
        {
            txtDireita.Text = "";
            lblNomeCandidato.Text = "";
            a = 0;
            num = "0";
            pictureBox1.Image = Properties.Resources.fundobranco_urna;
            candidato.nome = "";
            candidato.foto = "";
            candidato.setor = "";
            candidato.codigo = "";
            lblNomeCandidato.Text = "";
            voto = false;
            lbl_confirmar_voto.Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            votoembranco();
        }

        private void votoembranco()
        {
            pictureBox1.Image = Properties.Resources.fundobranco_urna;
            txtDireita.Text = "--";
            num = "99";
            candidato.codigo = "99";
            voto = true;
        }


        private void button13_Click(object sender, EventArgs e)
        {
            if(voto == false)
            {
                DAL dal = new DAL();
                string pastaRaiz;
                string caminhoImagem;
                candidato.nome = "";
                candidato = dal.SelectCandidato((Convert.ToInt32(num)).ToString());

                if (candidato.nome != null)
                {
                    lblNomeCandidato.Text = candidato.nome;
                    voto = true;
                    if (num != "99")
                    {
                        pastaRaiz = Application.StartupPath + "\\IMG\\";

                        caminhoImagem = Path.Combine(pastaRaiz, candidato.foto + ".jpg");

                        pictureBox1.Image = Image.FromFile(caminhoImagem);

                        lbl_confirmar_voto.Visible = true;

                    }

                }
                else
                {
                    limpar();

                    lblNomeCandidato.Text = "CANDIDATO NÃO ENCONTRADO";

                }

                lb_Matricula.Text = "";
                lb_Nome.Text = "";
            }
            else
            {
                DAL dal = new DAL();
                dal.InsertVoto(candidato.codigo);
                dal.UpdateEleitorVoto(matricula);

                Form2 form2 = new Form2();
                form2.ShowDialog();
                this.Close();
                
            }

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

      


    }
}






